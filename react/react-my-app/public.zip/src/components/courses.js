import React from 'react';

const Course = (props) => {
    return <p> student is enrolled in <b>{props.enrolled}</b> </p>;
}
 
export default Course;