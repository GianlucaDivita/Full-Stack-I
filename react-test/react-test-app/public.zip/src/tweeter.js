import React from "react";
import Like from "./Like";
import Timer from "./Timer";
import Comment from "./Comment";

class Tweeter extends React.Component {
  state = {  } 
  render() { 
    
    return <>


      <Comment/>
      
             

    </>
    ;
  }
}
 
export default Tweeter;